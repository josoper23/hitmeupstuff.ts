import { useEffect, useMemo, useState } from "react";
import { MotionConfig, motion, useReducedMotion, useScroll, useSpring } from "framer-motion";
import {
  ArrowDown,
  ArrowUpRight,
  ChevronDown,
  Globe2,
  Instagram,
  Mail,
  Menu,
  MousePointer2,
  Play,
  Sparkles,
  Twitch,
  X,
  Youtube,
} from "lucide-react";

const media = {
  wave:
    "https://files.manuscdn.com/search-media/310519664014509332/YwmNeUO9zlem5O3QBHOZoT/MgaZAFBeMkqXcuMdnbqUZ7.jpg",
  desk:
    "https://files.manuscdn.com/search-media/310519664014509332/YwmNeUO9zlem5O3QBHOZoT/oE3yk6v3ajy8vCcPexuhH6.jpg",
  studio:
    "https://files.manuscdn.com/search-media/310519664014509332/YwmNeUO9zlem5O3QBHOZoT/potX6oLRg7Stxsn9w57B6Q.jpg",
};

const socials = [
  { name: "Instagram", handle: "@joshhjozuphh", meta: "Daily fragments", href: "https://www.instagram.com/joshhjozuphh/", icon: Instagram, tone: "lilac" },
  { name: "YouTube", handle: "Josh Joseph", meta: "Films / process", href: "https://www.youtube.com/@joshhjozuphh", icon: Youtube, tone: "lime" },
  { name: "Twitch", handle: "joshhjozuphh", meta: "Live / making", href: "https://www.twitch.tv/joshhjozuphh", icon: Twitch, tone: "blue" },
  { name: "Email me", handle: "Drop me a line", meta: "Open inbox", href: "mailto:hello@nocturne.studio?subject=Hey%20Josh", icon: Mail, tone: "peach" },
];

const projects = [
  { number: "01", type: "sound / film", title: "A Place Between Signals", year: "2025", image: media.wave, accent: "blue" },
  { number: "02", type: "studio journal", title: "Notes from Room 404", year: "2025", image: media.desk, accent: "amber" },
  { number: "03", type: "visual research", title: "The Shape of Quiet", year: "2026", image: media.studio, accent: "violet" },
];

const sectionIds = ["home", "orbit", "work", "about"];

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24, scale: 0.985 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, amount: 0.18 }}
      transition={{ duration: 0.72, delay, ease: [0.22, 0.9, 0.24, 1] }}
    >
      {children}
    </motion.div>
  );
}

function ArrowButton({ children, onClick, variant = "solid" }: { children: React.ReactNode; onClick?: () => void; variant?: "solid" | "ghost" }) {
  return (
    <button type="button" onClick={onClick} className={`arrow-button ${variant}`}>
      <span>{children}</span>
      <span className="arrow-button-icon"><ArrowUpRight size={16} strokeWidth={1.6} /></span>
    </button>
  );
}

export default function Home() {
  const [active, setActive] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const shouldReduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.18 });

  useEffect(() => {
    const observers = sectionIds.map((id) => {
      const el = document.getElementById(id);
      if (!el) return null;
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActive(id);
        },
        { rootMargin: "-35% 0px -55% 0px", threshold: 0 }
      );
      observer.observe(el);
      return observer;
    });
    return () => observers.forEach((observer) => observer?.disconnect());
  }, []);

  const goTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: shouldReduceMotion ? "auto" : "smooth", block: "start" });
    setMenuOpen(false);
  };

  const year = useMemo(() => new Date().getFullYear(), []);

  return (
    <MotionConfig reducedMotion="user">
      <main className="site-shell">
        <div className="cosmic-backdrop" aria-hidden="true"><div className="starfield" /><div className="aurora aurora-one" /><div className="aurora aurora-two" /><div className="aurora aurora-three" /></div>
        <motion.div className="scroll-progress" style={{ scaleX: progress }} />
        <div className="grain" aria-hidden="true" />

        <header className="site-nav glass-card">
            <button type="button" className="wordmark" onClick={() => goTo("home")} aria-label="Go to the top">
            <span className="mark">JJ</span><span className="wordmark-copy">JOSH JOSEPH<span className="wordmark-dot">.</span></span>
          </button>
          <nav className={`nav-links ${menuOpen ? "open" : ""}`} aria-label="Primary navigation">
            {[{ id: "home", label: "Home" }, { id: "orbit", label: "Orbit" }, { id: "work", label: "Archive" }, { id: "about", label: "About" }].map((item) => (
              <button key={item.id} type="button" className={active === item.id ? "active" : ""} onClick={() => goTo(item.id)}><span>{item.label}</span>{active === item.id && <span className="nav-active-dot" />}</button>
            ))}
          </nav>
          <div className="nav-right"><a className="availability" href="mailto:hello@nocturne.studio?subject=Hey%20Josh"><span className="status-dot" /> Open to collabs</a><button className="menu-toggle" type="button" onClick={() => setMenuOpen((value) => !value)} aria-label={menuOpen ? "Close navigation" : "Open navigation"}>{menuOpen ? <X size={19} /> : <Menu size={19} />}</button></div>
        </header>

        <div className="site-main">
          <section id="home" className="hero-card glass-card section-anchor">
            <div className="avatar-wrap">
              <motion.div className="avatar profile-avatar" animate={shouldReduceMotion ? { y: 0 } : { y: [0, -7, 0] }} transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}>
                <img src="/manus-storage/josh-profile-v2_47975ee7.jpg" alt="Josh Joseph in a black hoodie in the city at night" width={1024} height={1024} decoding="async" />
              </motion.div>
              <span className="status" title="Online" />
            </div>
            <div className="hero-content">
              <Reveal className="eyebrow-row"><span className="eyebrow-mark" /> Independent creator / internet person</Reveal>
              <h1>JOSH JOSEPH</h1>
              <p className="handle">@joshhjozuphh <span>·</span> creator, designer and professional daydreamer</p>
              <p className="bio">Creator, designer and professional daydreamer. Making things on the internet and sharing the process.</p>
              <div className="chips"><span>Creator</span><span>Open to collabs</span><span>Replies within a day</span></div>
              <div className="hero-actions"><ArrowButton onClick={() => goTo("orbit")}>Find me online</ArrowButton><button type="button" className="text-link" onClick={() => goTo("work")}><span>See what I’m making</span><ArrowDown size={15} /></button></div>
            </div>
            <span className="hero-corner-label">ONLINE / EST. 2021</span>
          </section>

          <section id="orbit" className="section-anchor">
            <div className="section-label-row"><span className="section-number">01 — THE ORBIT</span><span className="tiny-caption">Tap a signal to tune in ↘</span></div>
            <div className="social-grid">
              {socials.map((social, index) => {
                const Icon = social.icon;
                return (
                  <Reveal key={social.name} delay={index * 0.07} className={`social-card glass-card ${social.tone} ${index < 2 ? "wide" : ""}`}>
                    <a href={social.href} target={social.name === "Newsletter" ? undefined : "_blank"} rel={social.name === "Newsletter" ? undefined : "noreferrer"} aria-label={`${social.name}: ${social.handle}`}>
                      <div className="social-card-top"><span className="social-icon"><Icon size={20} strokeWidth={1.6} /></span><ArrowUpRight size={19} strokeWidth={1.5} className="social-arrow" /></div>
                      <div className="social-card-bottom"><span className="social-name">{social.name}</span><span className="social-handle">{social.handle}</span><span className="social-meta">{social.meta}</span></div>
                      <span className="card-index">0{index + 1}</span>
                    </a>
                  </Reveal>
                );
              })}
            </div>
          </section>

          <section id="work" className="section-anchor glass-card gallery-card">
            <div className="gallery-head"><div><span className="section-number">02 — THE ARCHIVE</span><h2>Selected frequencies.</h2></div><span className="gallery-sub">A few things left glowing in the dark.</span></div>
            <div className="project-rail">
              {projects.map((project, index) => (
                <Reveal key={project.number} delay={index * 0.08} className="project-card">
                  <a href="#about" className="project-link">
                    <div className="project-media"><img src={project.image} alt={project.title} loading="lazy" decoding="async" /><div className="project-shade" /><span className="project-play">{index === 0 ? <Play size={17} fill="currentColor" /> : <ArrowUpRight size={19} />}</span><span className={`project-accent ${project.accent}`} /></div>
                    <div className="project-info"><div><span className="project-number">{project.number}</span><span className="project-type">{project.type}</span></div><h3>{project.title}</h3><span className="project-year">{project.year}</span></div>
                  </a>
                </Reveal>
              ))}
            </div>
          </section>

          <section id="about" className="about-card glass-card section-anchor">
            <div className="about-stamp"><div className="stamp-ring"><Globe2 size={23} strokeWidth={1.4} /><span>made<br />with<br />intent</span></div><span className="stamp-caption">Nocturne / Est. 2021</span></div>
            <div className="about-copy"><span className="section-number">03 — CONTEXT</span><h2>A little context.</h2><p>Creator, designer and professional daydreamer. Making things on the internet and sharing the process.</p><p className="muted-copy">Currently: exploring visual culture, building small internet worlds, and staying curious about what comes next.</p><div className="about-actions"><ArrowButton onClick={() => window.location.href = "mailto:hello@nocturne.studio?subject=Hey%20Josh"}>Say hello</ArrowButton><span className="mini-signature">JJ<span>.</span></span></div></div>
            <div className="about-quote"><span className="quote-mark">“</span><p>Pay attention to what you pay attention to.</p><span className="quote-credit">— I keep coming back to this</span></div>
          </section>

          <footer className="site-footer"><div className="footer-top"><span className="footer-kicker"><MousePointer2 size={15} /> Keep looking around.</span><button type="button" className="back-top" onClick={() => goTo("home")}>Back to top <ChevronDown size={16} className="rotate-180" /></button></div><div className="footer-main"><div className="footer-wordmark">JOSH JOSEPH<span>.</span></div><div className="footer-message">A small signal<br /><em>in a big feed.</em></div><div className="footer-meta"><a href="mailto:hello@nocturne.studio?subject=Hey%20Josh">hello@nocturne.studio</a><span>© {year} Josh Joseph</span></div></div><div className="footer-bottom"><span>Designed for the in-between.</span><div className="footer-links"><a href="#home">Privacy</a><a href="#home">Credits</a><a href="https://www.instagram.com/joshhjozuphh/" target="_blank" rel="noreferrer">Instagram ↗</a></div></div></footer>
        </div>
      </main>
    </MotionConfig>
  );
}
